package com.shuangyulin.Utils;

/*���ӳع����࣬����Ψһ��һ����ݿ����ӳض���*/
public class ConnectionPoolUtils {
	private static ConnectionPool poolInstance = null;
	public static ConnectionPool GetPoolInstance(){
		if(poolInstance == null) {
			poolInstance = new ConnectionPool(
					//"com.microsoft.jdbc.sqlserver.SQLServerDriver",
					"com.mysql.jdbc.Driver",
					//"jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=SuperMarketInfo",
					"jdbc:mysql://127.0.0.1:3306/zzytest?user=root&useUnicode=true&characterEncoding=UTF-8",
					//"jdbc:sqlserver://localhost;database=SuperMarketInfo;IntegratedSecurity=false;",&password=0577668
					"root", "");
			try {
				poolInstance.createPool();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return poolInstance;
	}
}
