package edu.dao;

import java.sql.ResultSet;

import com.shuangyulin.Utils.DB;

import edu.user.bean.UserInfo;

public class UserDao {
	
	public boolean checkLogin(UserInfo userInfo) {
		DB db = new DB();
		boolean flag = false;
		String sql = "select * from user where id='"
				+ userInfo.getUserId() + "' and pwd='"
				+ userInfo.getPwd() + "'";
		try {
			ResultSet rs = db.executeQuery(sql);
			if (rs.next())
				flag = true;
			else
				flag = false;
			db.all_close();
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		} 
		return flag;
	}
}
