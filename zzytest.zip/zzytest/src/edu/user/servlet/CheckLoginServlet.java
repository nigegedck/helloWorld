package edu.user.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import edu.dao.UserDao;
import edu.user.bean.UserInfo;

public class CheckLoginServlet extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		String Id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		System.out.println(Id+"..."+pwd);
		
		UserInfo userInfo = new UserInfo();
		userInfo.setUserId(Id);
		userInfo.setPwd(pwd);
		
		UserDao userDao = new UserDao();
		if (userDao.checkLogin(userInfo)) {
			session.setAttribute("userId", Id);
			response.sendRedirect("index.jsp");
		} else {
			String errMessage;
			errMessage = "账号密码错误!";
			request.setAttribute("errMessage",errMessage);
			RequestDispatcher wm = request.getRequestDispatcher("login.jsp");
			wm.forward(request, response);
		}
	}

}
